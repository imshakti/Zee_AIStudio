import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Theme = 'nature' | 'ocean' | 'energy';

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const themes: Record<Theme, Record<string, string>> = {
  nature: {
    '--color-eco-50': '#f0fdf4',
    '--color-eco-100': '#dcfce7',
    '--color-eco-200': '#bbf7d0',
    '--color-eco-300': '#86efac',
    '--color-eco-400': '#4ade80',
    '--color-eco-500': '#22c55e',
    '--color-eco-600': '#16a34a',
    '--color-eco-700': '#15803d',
    '--color-eco-800': '#166534',
    '--color-eco-900': '#14532d',
    '--color-eco-950': '#052e16',
  },
  ocean: {
    '--color-eco-50': '#f0f9ff',
    '--color-eco-100': '#e0f2fe',
    '--color-eco-200': '#bae6fd',
    '--color-eco-300': '#7dd3fc',
    '--color-eco-400': '#38bdf8',
    '--color-eco-500': '#0ea5e9',
    '--color-eco-600': '#0284c7',
    '--color-eco-700': '#0369a1',
    '--color-eco-800': '#075985',
    '--color-eco-900': '#0c4a6e',
    '--color-eco-950': '#082f49',
  },
  energy: {
    '--color-eco-50': '#fff7ed',
    '--color-eco-100': '#ffedd5',
    '--color-eco-200': '#fed7aa',
    '--color-eco-300': '#fdba74',
    '--color-eco-400': '#fb923c',
    '--color-eco-500': '#f97316',
    '--color-eco-600': '#ea580c',
    '--color-eco-700': '#c2410c',
    '--color-eco-800': '#9a3412',
    '--color-eco-900': '#7c2d12',
    '--color-eco-950': '#431407',
  }
};

export const ThemeProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [theme, setTheme] = useState<Theme>('nature');

  useEffect(() => {
    const root = document.documentElement;
    const colors = themes[theme];
    Object.entries(colors).forEach(([key, value]) => {
      root.style.setProperty(key, value as string);
    });
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};