export interface NavItem {
  label: string;
  path: string;
}

export interface ServiceData {
  title: string;
  description: string;
  iconName: string;
}

export interface StatData {
  value: string;
  label: string;
}

export interface ProjectData {
  id: number;
  title: string;
  location: string;
  capacity: string;
  image: string;
}