import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Leaf, Palette } from 'lucide-react';
import { NAV_ITEMS } from '../constants';
import { useTheme } from '../context/ThemeContext';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [showThemeMenu, setShowThemeMenu] = useState(false);
  const location = useLocation();
  const { theme, setTheme } = useTheme();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setIsOpen(false);
    setShowThemeMenu(false);
  }, [location]);

  return (
    <header 
      className={`fixed top-0 w-full z-50 transition-all duration-500 ${
        scrolled 
          ? 'bg-white/85 backdrop-blur-xl shadow-md border-b border-gray-200/50 py-3' 
          : 'bg-transparent py-5 border-transparent'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 group relative z-50">
          <div className="bg-gradient-to-br from-eco-500 to-eco-700 text-white p-2.5 rounded-xl shadow-lg group-hover:shadow-eco-500/30 transition-all duration-300">
            <Leaf size={24} className="fill-current" />
          </div>
          <span className={`font-heading font-bold text-xl md:text-2xl tracking-tight transition-colors duration-300 ${scrolled ? 'text-gray-900' : 'text-white md:text-white text-gray-900'}`}>
            ZERO<span className="text-eco-500">EMISSION</span>
          </span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-4">
          <nav className={`flex items-center gap-1 p-1.5 rounded-full border transition-all duration-500 ${
            scrolled ? 'bg-gray-100/50 border-gray-200' : 'bg-white/10 border-white/20 backdrop-blur-sm'
          }`}>
            {NAV_ITEMS.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`font-medium text-sm px-5 py-2 rounded-full transition-all duration-300 ${
                    isActive
                      ? 'bg-white text-eco-700 shadow-sm'
                      : scrolled 
                        ? 'text-gray-600 hover:text-eco-700 hover:bg-white/80' 
                        : 'text-white hover:bg-white/20'
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
          
          {/* Theme Switcher - Desktop */}
          <div className="relative">
            <button 
              onClick={() => setShowThemeMenu(!showThemeMenu)}
              className={`p-2.5 rounded-full transition-all duration-300 ${
                scrolled 
                  ? 'bg-gray-100/50 hover:bg-eco-50 text-gray-600 hover:text-eco-600' 
                  : 'bg-white/10 hover:bg-white/20 text-white border border-white/20'
              }`}
              aria-label="Change Theme"
            >
              <Palette size={20} />
            </button>
            
            {showThemeMenu && (
              <div className="absolute top-full right-0 mt-3 p-2 bg-white rounded-2xl shadow-xl border border-gray-100 w-48 animate-fade-in-up">
                 <div className="text-xs font-bold text-gray-400 uppercase tracking-wider px-3 py-2">Select Theme</div>
                 <div className="space-y-1">
                   {[
                     { id: 'nature', label: 'Nature', color: '#22c55e' },
                     { id: 'ocean', label: 'Ocean', color: '#0ea5e9' },
                     { id: 'energy', label: 'Energy', color: '#f97316' }
                   ].map((t) => (
                     <button
                        key={t.id}
                        onClick={() => { setTheme(t.id as any); setShowThemeMenu(false); }}
                        className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition-colors ${theme === t.id ? 'bg-gray-100 text-gray-900' : 'text-gray-600 hover:bg-gray-50'}`}
                     >
                        <span className="w-4 h-4 rounded-full shadow-sm" style={{ backgroundColor: t.color }}></span>
                        {t.label}
                     </button>
                   ))}
                 </div>
              </div>
            )}
          </div>

          {/* CTA Button */}
          <Link
            to="/contact"
            className="bg-gradient-to-r from-eco-600 to-eco-500 hover:from-eco-700 hover:to-eco-600 text-white font-heading font-semibold py-2.5 px-6 rounded-full transition-all duration-300 shadow-lg shadow-eco-500/30 hover:shadow-eco-500/50 hover:-translate-y-0.5"
          >
            Get a Quote
          </Link>
        </div>

        {/* Mobile Menu Toggle */}
        <button
          className={`md:hidden p-2 rounded-lg transition-colors z-50 ${scrolled ? 'text-gray-800' : 'text-white'}`}
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X size={28} className="text-gray-800" /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu Dropdown */}
      <div
        className={`md:hidden fixed inset-0 bg-white z-40 transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full pt-24 px-6 space-y-6 overflow-y-auto">
          {NAV_ITEMS.map((item, idx) => (
            <Link
              key={item.path}
              to={item.path}
              style={{ animationDelay: `${idx * 100}ms` }}
              className={`font-heading font-bold text-2xl ${
                isOpen ? 'animate-fade-in-up' : 'opacity-0'
              } ${
                location.pathname === item.path ? 'text-eco-600' : 'text-gray-800'
              }`}
            >
              {item.label}
            </Link>
          ))}
          
          <div className="py-6 border-t border-gray-100">
             <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">Theme</div>
             <div className="flex gap-4">
                 {[
                   { id: 'nature', label: 'Nature', color: '#22c55e' },
                   { id: 'ocean', label: 'Ocean', color: '#0ea5e9' },
                   { id: 'energy', label: 'Energy', color: '#f97316' }
                   ].map((t) => (
                   <button
                      key={t.id}
                      onClick={() => setTheme(t.id as any)}
                      className={`flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all ${theme === t.id ? 'border-gray-900 bg-gray-50' : 'border-gray-100'}`}
                   >
                      <span className="w-8 h-8 rounded-full shadow-sm" style={{ backgroundColor: t.color }}></span>
                      <span className="text-xs font-medium text-gray-600">{t.label}</span>
                   </button>
                 ))}
             </div>
          </div>

          <Link
            to="/contact"
            className="bg-eco-600 text-white text-center font-heading font-bold text-lg py-4 rounded-xl shadow-xl mt-auto mb-8"
          >
            Get a Quote
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Header;