import { NavItem, ServiceData, StatData, ProjectData } from './types';

export const COMPANY_NAME = "Zero Emission Energy";
export const ADDRESS = "B/h Gadhawala Hospital Nr. Kirtisthambh Palanpur - 385 001, Gujarat";
export const PHONE = "+91 98765 43210";
export const EMAIL = "info@zeroemission.co.in";

export const NAV_ITEMS: NavItem[] = [
  { label: 'Home', path: '/' },
  { label: 'About', path: '/about' },
  { label: 'Projects', path: '/projects' },
  { label: 'Gallery', path: '/gallery' },
  { label: 'Contact', path: '/contact' },
];

export const SERVICES: ServiceData[] = [
  {
    title: "Corporate Biogas Setup",
    description: "Large-scale turnkey biogas plants for industries, dairies, and institutions to generate renewable power.",
    iconName: "Factory"
  },
  {
    title: "Individual Biogas Units",
    description: "Compact, efficient biogas solutions for individual households and farms for cooking and heating.",
    iconName: "Sprout"
  },
  {
    title: "Solid Waste Management",
    description: "Comprehensive systems for collecting, treating, and recycling organic solid waste.",
    iconName: "Recycle"
  },
  {
    title: "Sewage Treatment (STP)",
    description: "Advanced Sewage Treatment Plants for residential societies and commercial complexes.",
    iconName: "Droplets"
  },
  {
    title: "Water Recycling",
    description: "Sustainable water reclamation systems to treat and reuse wastewater for non-potable purposes.",
    iconName: "Droplets"
  },
  {
    title: "Effluent Treatment (ETP)",
    description: "Industrial grade treatment plants to process harmful effluents and ensure regulatory compliance.",
    iconName: "Wrench"
  }
];

export const STATS: StatData[] = [
  { value: "50,000+", label: "cum Biogas Generated" },
  { value: "100+", label: "Corporate Projects" },
  { value: "500+", label: "Individual Units" },
  { value: "10M+", label: "Liters Water Treated" }
];

export const PROJECTS: ProjectData[] = [
  {
    id: 1,
    title: "Corporate Dairy Biogas Plant",
    location: "Banaskantha, Gujarat",
    capacity: "5000 cum/day",
    // Matches the "Green dome tank in field at sunset" vibe
    image: "https://images.unsplash.com/photo-1532601224476-15c79f2f7a51?q=80&w=2070&auto=format&fit=crop"
  },
  {
    id: 2,
    title: "CBG Processing Facility",
    location: "Ahmedabad, Gujarat",
    capacity: "200 TPD Waste",
    // Matches the "Indoor green tanks with silver pipes" vibe
    image: "https://images.unsplash.com/photo-1581093588401-fbb0777894a7?q=80&w=2068&auto=format&fit=crop"
  },
  {
    id: 3,
    title: "Industrial STP & Recycling",
    location: "Mehsana, Gujarat",
    capacity: "500 KLD Water",
    // High quality industrial water treatment
    image: "https://images.unsplash.com/photo-1574972740730-811c7755b411?q=80&w=1974&auto=format&fit=crop"
  }
];