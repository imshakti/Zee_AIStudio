import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send } from 'lucide-react';
import { ADDRESS, PHONE, EMAIL } from '../constants';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Thank you for your inquiry. We will get back to you shortly.');
    setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
  };

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="bg-gray-900 pt-32 pb-24 relative overflow-hidden">
        <div className="absolute inset-0 z-0">
           <img 
             src="https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=2069&auto=format&fit=crop" 
             alt="Office Contact" 
             className="w-full h-full object-cover opacity-60"
           />
           <div className="absolute inset-0 bg-gradient-to-b from-gray-900/50 via-gray-900/80 to-gray-900"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="font-heading text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-in-up drop-shadow-md">Contact Us</h1>
          <p className="text-xl text-gray-100 max-w-2xl mx-auto font-light animate-fade-in-up-delay drop-shadow-sm">
            Ready to start your Biogas or Water Treatment project? Get in touch today.
          </p>
        </div>
      </div>

      <section className="py-24 -mt-20 relative z-20">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-8 mb-20">
            
            {/* Contact Info */}
            <div className="lg:col-span-1 space-y-6">
              <div className="bg-white p-8 rounded-2xl shadow-xl shadow-gray-200/50 border border-gray-100 h-full animate-fade-in-up">
                <h3 className="font-heading text-2xl font-bold text-gray-900 mb-8">Get in Touch</h3>
                
                <div className="space-y-8">
                  <div className="flex items-start gap-4">
                    <div className="bg-eco-50 p-3 rounded-xl text-eco-600">
                      <MapPin size={24} />
                    </div>
                    <div>
                      <p className="font-bold text-gray-900 text-lg mb-1">Our Office</p>
                      <p className="text-gray-600 leading-relaxed">{ADDRESS}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-eco-50 p-3 rounded-xl text-eco-600">
                      <Phone size={24} />
                    </div>
                    <div>
                      <p className="font-bold text-gray-900 text-lg mb-1">Phone</p>
                      <p className="text-gray-600 text-lg">{PHONE}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-eco-50 p-3 rounded-xl text-eco-600">
                      <Mail size={24} />
                    </div>
                    <div>
                      <p className="font-bold text-gray-900 text-lg mb-1">Email</p>
                      <p className="text-gray-600">{EMAIL}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-eco-50 p-3 rounded-xl text-eco-600">
                      <Clock size={24} />
                    </div>
                    <div>
                      <p className="font-bold text-gray-900 text-lg mb-1">Working Hours</p>
                      <p className="text-gray-600">Mon - Sat: 9:00 AM - 6:00 PM</p>
                      <p className="text-gray-500 text-sm mt-1">Sunday: Closed</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <div className="bg-white p-8 md:p-12 rounded-2xl shadow-xl shadow-gray-200/50 border border-gray-100 animate-fade-in-up-delay">
                <h3 className="font-heading text-2xl font-bold text-gray-900 mb-8">Send us a Message</h3>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="group">
                      <label htmlFor="name" className="block text-sm font-semibold text-gray-700 mb-2 ml-1">Your Name</label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="w-full px-5 py-4 rounded-xl bg-gray-50 border-gray-200 border focus:border-eco-500 focus:bg-white focus:ring-4 focus:ring-eco-500/10 outline-none transition-all duration-300"
                        placeholder="John Doe"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2 ml-1">Email Address</label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full px-5 py-4 rounded-xl bg-gray-50 border-gray-200 border focus:border-eco-500 focus:bg-white focus:ring-4 focus:ring-eco-500/10 outline-none transition-all duration-300"
                        placeholder="john@company.com"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="phone" className="block text-sm font-semibold text-gray-700 mb-2 ml-1">Phone Number</label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-5 py-4 rounded-xl bg-gray-50 border-gray-200 border focus:border-eco-500 focus:bg-white focus:ring-4 focus:ring-eco-500/10 outline-none transition-all duration-300"
                        placeholder="+91 98765 43210"
                      />
                    </div>
                    <div>
                      <label htmlFor="subject" className="block text-sm font-semibold text-gray-700 mb-2 ml-1">Service Interest</label>
                      <select
                        id="subject"
                        name="subject"
                        value={formData.subject}
                        onChange={handleChange}
                        className="w-full px-5 py-4 rounded-xl bg-gray-50 border-gray-200 border focus:border-eco-500 focus:bg-white focus:ring-4 focus:ring-eco-500/10 outline-none transition-all duration-300 appearance-none"
                      >
                        <option value="">Select a topic</option>
                        <option value="corporate-biogas">Corporate Biogas Plant</option>
                        <option value="individual-biogas">Individual Biogas Unit</option>
                        <option value="waste-management">Solid Waste Management</option>
                        <option value="stp">Sewage Treatment (STP)</option>
                        <option value="water-recycling">Water Recycling</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-semibold text-gray-700 mb-2 ml-1">Message</label>
                    <textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      rows={5}
                      className="w-full px-5 py-4 rounded-xl bg-gray-50 border-gray-200 border focus:border-eco-500 focus:bg-white focus:ring-4 focus:ring-eco-500/10 outline-none transition-all duration-300 resize-none"
                      placeholder="Tell us about your project requirements..."
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    className="w-full md:w-auto bg-gradient-to-r from-eco-600 to-eco-500 hover:from-eco-700 hover:to-eco-600 text-white font-heading font-bold py-4 px-10 rounded-xl transition-all duration-300 flex items-center justify-center gap-2 shadow-lg shadow-eco-500/30 hover:shadow-eco-500/50 hover:-translate-y-1"
                  >
                    Send Message <Send size={18} />
                  </button>
                </form>
              </div>
            </div>
          </div>

          {/* Map Section */}
          <div className="w-full h-96 rounded-2xl overflow-hidden shadow-xl border border-gray-100 animate-fade-in-up">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3655.249272378945!2d72.43438031536484!3d24.172288984382583!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395ce94071371727%3A0x6296333671217e58!2sKirti%20Stambh%2C%20Palanpur%2C%20Gujarat%20385001!5e0!3m2!1sen!2sin!4v1677651234567!5m2!1sen!2sin" 
              width="100%" 
              height="100%" 
              style={{border:0}} 
              allowFullScreen={true} 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              title="Google Maps Location"
            ></iframe>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;