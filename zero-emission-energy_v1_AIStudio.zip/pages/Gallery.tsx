import React from 'react';
import { Plus } from 'lucide-react';

const Gallery: React.FC = () => {
  const images = [
    "https://images.unsplash.com/photo-1532601224476-15c79f2f7a51?q=80&w=2070&auto=format&fit=crop", // Biogas
    "https://images.unsplash.com/photo-1622325036128-29a32c6680a6?q=80&w=2070&auto=format&fit=crop", // Tanks
    "https://images.unsplash.com/photo-1581093458791-9f3c3900df4b?q=80&w=2070&auto=format&fit=crop", // Water
    "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?q=80&w=2070&auto=format&fit=crop", // Waste
    "https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?q=80&w=1974&auto=format&fit=crop", // Industrial
    "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?q=80&w=2070&auto=format&fit=crop", // Industrial 2
  ];

  return (
    <div className="bg-white min-h-screen">
      <div className="bg-gray-900 pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?q=80&w=2069&auto=format&fit=crop" 
            alt="Gallery Header" 
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-gray-900/50 via-gray-900/80 to-gray-900"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10 text-center">
           <span className="text-eco-400 font-bold tracking-widest uppercase text-sm mb-4 block animate-fade-in text-shadow-sm">Portfolio</span>
          <h1 className="font-heading text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-in-up drop-shadow-md">Our Work Gallery</h1>
          <p className="text-xl text-gray-100 max-w-2xl mx-auto font-light animate-fade-in-up-delay drop-shadow-sm">A glimpse into our Biogas, Waste Management, and Water Treatment installations.</p>
        </div>
      </div>

      <section className="py-24">
        <div className="container mx-auto px-4">
          <div className="columns-1 md:columns-2 lg:columns-3 gap-8 space-y-8">
            {images.map((src, idx) => (
              <div 
                key={idx} 
                className="break-inside-avoid relative group rounded-2xl overflow-hidden cursor-pointer animate-fade-in-up"
                style={{ animationDelay: `${idx * 100}ms` }}
              >
                <img 
                  src={src} 
                  alt={`Project image ${idx + 1}`} 
                  className="w-full h-auto transform group-hover:scale-110 transition-transform duration-700 ease-in-out" 
                />
                <div className="absolute inset-0 bg-gray-900/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center backdrop-blur-sm">
                   <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                     <button className="bg-white text-gray-900 rounded-full p-4 shadow-xl hover:scale-110 transition-transform">
                        <Plus size={24} />
                     </button>
                   </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Gallery;