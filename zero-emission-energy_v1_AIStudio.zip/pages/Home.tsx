import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Factory, Recycle, Droplets, FileText, Wrench, Sprout, CheckCircle2 } from 'lucide-react';
import { STATS, SERVICES } from '../constants';

// Helper component for counting up numbers
const AnimatedCounter: React.FC<{ value: string; label: string }> = ({ value, label }) => {
  const [count, setCount] = useState(0);
  const elementRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  // Extract numeric part and suffix (e.g., "50,000+" -> 50000 and "+")
  const numericMatch = value.match(/[\d,]+/);
  const numericValue = numericMatch ? parseInt(numericMatch[0].replace(/,/g, ''), 10) : 0;
  // Reconstruct prefix/suffix
  const prefix = value.substring(0, value.indexOf(numericMatch?.[0] || ''));
  const suffix = value.substring((value.indexOf(numericMatch?.[0] || '') + (numericMatch?.[0].length || 0)));

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (elementRef.current) {
      observer.observe(elementRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible || numericValue === 0) return;

    let startTime: number;
    let animationFrame: number;
    const duration = 2000; // 2 seconds

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const progress = currentTime - startTime;

      if (progress < duration) {
        const nextCount = Math.min(Math.floor((progress / duration) * numericValue), numericValue);
        setCount(nextCount);
        animationFrame = requestAnimationFrame(animate);
      } else {
        setCount(numericValue);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, [isVisible, numericValue]);

  return (
    <div ref={elementRef} className="p-8 text-center hover:bg-gray-50 transition-colors group">
      <div className="text-3xl md:text-4xl lg:text-5xl font-heading font-bold text-gray-900 mb-2 group-hover:text-eco-600 transition-colors flex justify-center items-baseline">
        <span>{prefix}</span>
        <span>{count.toLocaleString()}</span>
        <span>{suffix}</span>
      </div>
      <div className="text-sm font-medium text-gray-500 uppercase tracking-wider">{label}</div>
    </div>
  );
};

const Home: React.FC = () => {
  const getIcon = (name: string) => {
    switch (name) {
      case 'Factory': return <Factory size={32} className="text-white" />;
      case 'Recycle': return <Recycle size={32} className="text-white" />;
      case 'Droplets': return <Droplets size={32} className="text-white" />;
      case 'FileText': return <FileText size={32} className="text-white" />;
      case 'Wrench': return <Wrench size={32} className="text-white" />;
      case 'Sprout': return <Sprout size={32} className="text-white" />;
      default: return <Factory size={32} className="text-white" />;
    }
  };

  return (
    <>
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pb-48 md:pb-60">
        <div className="absolute inset-0 z-0">
          {/* Updated Hero Image - Green Biogas Tanks at Sunset */}
          <img 
            src="hero-biogas-plant.jpg" 
            alt="Advanced Biogas Plant at Sunset" 
            className="w-full h-full object-cover scale-105 animate-fade-in"
          />
          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-r from-gray-900/90 via-gray-900/60 to-gray-900/30"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent"></div>
        </div>
        
        <div className="relative z-10 container mx-auto px-4 pt-20">
          <div className="max-w-4xl">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-eco-300 font-medium text-sm mb-6 animate-fade-in-up">
              <span className="w-2 h-2 rounded-full bg-eco-400 animate-pulse"></span>
              Biogas • Waste Management • Water Recycling
            </div>
            
            <h1 className="font-heading text-5xl md:text-7xl lg:text-8xl font-bold mb-8 leading-[1.1] text-white tracking-tight animate-fade-in-up">
              Advanced <span className="text-transparent bg-clip-text bg-gradient-to-r from-eco-400 to-teal-300">Bio-Energy</span> & <br />
              Water Solutions
            </h1>
            
            <p className="text-lg md:text-xl text-gray-300 mb-10 max-w-2xl font-light leading-relaxed animate-fade-in-up-delay">
              Specializing in Individual & Corporate Biogas Plant setups, Solid Waste Management systems, and advanced Sewage Treatment Solutions.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 animate-fade-in-up-delay">
              <Link 
                to="/contact" 
                className="bg-eco-600 hover:bg-eco-500 text-white font-heading font-semibold py-4 px-8 rounded-full transition-all duration-300 shadow-[0_0_20px_rgba(34,197,94,0.3)] hover:shadow-[0_0_30px_rgba(34,197,94,0.5)] transform hover:-translate-y-1 text-center"
              >
                Get a Quote
              </Link>
              <Link 
                to="/projects" 
                className="group bg-white/5 hover:bg-white/10 backdrop-blur-sm border border-white/20 text-white font-heading font-semibold py-4 px-8 rounded-full transition-all duration-300 flex items-center justify-center gap-2"
              >
                View Projects <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Floating Stats Section with Animation */}
      <div className="relative z-20 container mx-auto px-4 -mt-24 mb-20">
        <div className="grid grid-cols-2 md:grid-cols-4 bg-white rounded-3xl shadow-2xl shadow-black/10 divide-x divide-gray-100 overflow-hidden border border-gray-100 animate-fade-in-up-delay">
          {STATS.map((stat, index) => (
            <AnimatedCounter key={index} value={stat.value} label={stat.label} />
          ))}
        </div>
      </div>

      {/* Intro Section */}
      <section className="py-20 bg-white overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div className="relative group">
               <div className="absolute -inset-4 bg-gradient-to-r from-eco-100 to-teal-100 rounded-3xl transform rotate-3 opacity-50 group-hover:rotate-6 transition-transform duration-500"></div>
               {/* Updated Intro Image - Reliable Industrial Pipes/Tanks URL */}
               <img 
                 src="https://images.unsplash.com/photo-1581093450021-4a7360e9a6b5?q=80&w=2070&auto=format&fit=crop" 
                 alt="Biogas Facility" 
                 className="relative rounded-2xl shadow-2xl w-full object-cover aspect-[4/3] transform transition-transform duration-500 hover:scale-[1.02]" 
               />
               <div className="absolute -bottom-10 -right-10 bg-white p-8 rounded-2xl shadow-xl hidden lg:block border border-gray-100">
                 <div className="flex items-center gap-4">
                   <div className="bg-eco-100 p-3 rounded-full text-eco-600">
                     <CheckCircle2 size={32} />
                   </div>
                   <div>
                     <p className="font-heading font-bold text-4xl text-gray-900">100%</p>
                     <p className="text-sm font-medium text-gray-500 uppercase tracking-wide">Green Compliance</p>
                   </div>
                 </div>
               </div>
            </div>
            
            <div className="relative">
              <h4 className="text-eco-600 font-bold uppercase tracking-widest text-sm mb-4">Core Expertise</h4>
              <h2 className="font-heading text-4xl md:text-5xl font-bold text-gray-900 mb-6 leading-tight">
                Sustainable Infrastructure for <br />
                <span className="relative inline-block text-eco-600">
                  Waste & Water
                </span>
              </h2>
              <p className="text-gray-600 text-lg mb-8 leading-relaxed">
                We deliver complete environmental engineering solutions. From <strong>Biogas plants</strong> for homes and factories to comprehensive <strong>Solid Waste Management</strong> and <strong>Sewage Treatment Plants (STP)</strong>, we help you turn liabilities into assets.
              </p>
              
              <div className="space-y-4 mb-8">
                {['Biogas for Individual & Corporate', 'Solid Waste Management', 'Water Recycling & Sewage Treatment'].map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-eco-100 flex items-center justify-center text-eco-600">
                      <CheckCircle2 size={14} />
                    </div>
                    <span className="font-medium text-gray-700">{item}</span>
                  </div>
                ))}
              </div>

              <Link to="/about" className="inline-flex items-center text-white bg-gray-900 hover:bg-gray-800 px-8 py-4 rounded-full font-semibold transition-all group">
                Discover More <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={18} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-24 bg-gray-50/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-20 max-w-3xl mx-auto">
            <h4 className="text-eco-600 font-bold uppercase tracking-widest text-sm mb-3">Our Services</h4>
            <h2 className="font-heading text-4xl md:text-5xl font-bold text-gray-900 mb-6">Complete Environmental Solutions</h2>
            <p className="text-gray-500 text-lg">Specialized engineering for Biogas, Waste, and Water treatment.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {SERVICES.map((service, index) => (
              <div 
                key={index} 
                className="bg-white p-10 rounded-2xl shadow-lg shadow-gray-200/50 hover:shadow-2xl hover:shadow-eco-900/10 hover:-translate-y-2 transition-all duration-300 group border border-gray-100 flex flex-col items-start relative overflow-hidden"
              >
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-eco-400 to-eco-600 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left"></div>
                <div className="w-16 h-16 bg-gradient-to-br from-eco-500 to-eco-600 rounded-2xl flex items-center justify-center mb-8 shadow-lg shadow-eco-500/30 group-hover:scale-110 transition-transform duration-300">
                  {getIcon(service.iconName)}
                </div>
                <h3 className="font-heading text-2xl font-bold text-gray-900 mb-4 group-hover:text-eco-600 transition-colors">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed mb-6">
                  {service.description}
                </p>
                <Link to="/contact" className="mt-auto inline-flex items-center text-eco-600 font-bold text-sm uppercase tracking-wider group-hover:gap-2 transition-all">
                  Get Details <ArrowRight size={16} className="ml-1 opacity-0 group-hover:opacity-100 transition-opacity" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative overflow-hidden bg-gray-900">
        <div className="absolute inset-0 z-0 opacity-20">
             <img src="https://images.unsplash.com/photo-1581093458791-9f3c3900df4b?q=80&w=2070&auto=format&fit=crop" className="w-full h-full object-cover grayscale" alt="Water treatment" />
        </div>
        <div className="absolute inset-0 bg-gradient-to-br from-eco-900/90 to-gray-900/95 z-10"></div>
        
        <div className="container mx-auto px-4 text-center relative z-20">
          <h2 className="font-heading text-4xl md:text-6xl font-bold text-white mb-8 tracking-tight">Need a Biogas or STP Solution?</h2>
          <p className="text-gray-300 text-xl max-w-2xl mx-auto mb-12 font-light">
            We provide customized setup for industries, societies, and municipalities. Let's discuss your requirements.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Link 
              to="/contact" 
              className="bg-white text-gray-900 font-heading font-bold py-4 px-10 rounded-full hover:bg-gray-100 transition-colors shadow-xl transform hover:-translate-y-1"
            >
              Contact Us
            </Link>
            <Link 
              to="/projects" 
              className="bg-transparent border border-white/30 text-white font-heading font-bold py-4 px-10 rounded-full hover:bg-white/10 transition-colors backdrop-blur-sm"
            >
              See Our Work
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;