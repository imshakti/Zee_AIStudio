import React from 'react';
import { Target, Eye, Users, Leaf, ShieldCheck, TrendingUp } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="bg-white">
      {/* Page Header */}
      <div className="bg-gray-900 pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=2070&auto=format&fit=crop" 
            alt="Engineering Team" 
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-gray-900/50 via-gray-900/80 to-gray-900"></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10 text-center">
          <span className="text-eco-400 font-bold tracking-widest uppercase text-sm mb-4 block animate-fade-in text-shadow-sm">Our Company</span>
          <h1 className="font-heading text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-in-up drop-shadow-md">About Zero Emission</h1>
          <p className="text-xl text-gray-100 max-w-2xl mx-auto font-light animate-fade-in-up-delay drop-shadow-sm">
            Leaders in Biogas, Solid Waste Management, and Water Treatment Solutions.
          </p>
        </div>
      </div>

      {/* Main Content */}
      <section className="py-24">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-16 items-center mb-24">
             <div className="order-2 lg:order-1">
                <h2 className="font-heading text-3xl md:text-4xl font-bold text-gray-900 mb-6 leading-tight">
                  Holistic Environmental <br /><span className="text-eco-600">Engineering</span>
                </h2>
                <p className="text-gray-600 text-lg leading-relaxed mb-6">
                  Zero Emission Energy was founded to provide comprehensive environmental solutions. Based in Palanpur, Gujarat, we specialize in three core areas: <strong>Biogas Plant Setup</strong> (Individual & Corporate), <strong>Solid Waste Management</strong>, and <strong>Water Recycling/Sewage Treatment</strong>.
                </p>
                <p className="text-gray-600 text-lg leading-relaxed mb-8">
                  We empower industries, communities, and municipalities to manage their waste responsibly and generate clean energy, ensuring a sustainable future for all.
                </p>
                <div className="grid grid-cols-2 gap-6">
                   <div className="p-4 bg-gray-50 rounded-xl border border-gray-100">
                      <h4 className="font-bold text-3xl text-eco-600 mb-1">100+</h4>
                      <p className="text-sm font-medium text-gray-600">Corporate Clients</p>
                   </div>
                   <div className="p-4 bg-gray-50 rounded-xl border border-gray-100">
                      <h4 className="font-bold text-3xl text-eco-600 mb-1">500+</h4>
                      <p className="text-sm font-medium text-gray-600">Individual Units</p>
                   </div>
                </div>
             </div>
             <div className="order-1 lg:order-2 relative">
                <img 
                  src="https://images.unsplash.com/photo-1542601906990-b4d3fb7d5c73?q=80&w=1974&auto=format&fit=crop" 
                  alt="Industrial Plant" 
                  className="rounded-2xl shadow-2xl w-full object-cover aspect-square"
                />
                <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-xl border border-gray-100 max-w-xs hidden md:block">
                  <p className="italic text-gray-600 text-sm">"Setting new benchmarks in waste-to-energy and water treatment."</p>
                </div>
             </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-24">
            <div className="bg-gradient-to-br from-eco-50 to-white p-10 rounded-3xl border border-eco-100 hover:shadow-lg transition-shadow">
              <div className="w-14 h-14 bg-eco-600 rounded-2xl flex items-center justify-center text-white mb-6 shadow-lg shadow-eco-500/30">
                <Target size={28} />
              </div>
              <h3 className="font-heading text-2xl font-bold text-gray-900 mb-4">Our Mission</h3>
              <p className="text-gray-700 text-lg leading-relaxed">
                To provide effective solutions for Biogas generation, Solid Waste Management, and Water Recycling, helping reduce fossil fuel consumption and pollution.
              </p>
            </div>

            <div className="bg-gradient-to-br from-gray-50 to-white p-10 rounded-3xl border border-gray-100 hover:shadow-lg transition-shadow">
              <div className="w-14 h-14 bg-gray-900 rounded-2xl flex items-center justify-center text-white mb-6 shadow-lg shadow-gray-900/30">
                <Eye size={28} />
              </div>
              <h3 className="font-heading text-2xl font-bold text-gray-900 mb-4">Our Vision</h3>
              <p className="text-gray-700 text-lg leading-relaxed">
                Committed to set new benchmarks in manufacturing of Biogas plants and Treatment systems through innovation and quality.
              </p>
            </div>
          </div>

          <div className="text-center mb-16">
            <h2 className="font-heading text-3xl font-bold text-gray-900 mb-4">Core Values</h2>
            <p className="text-gray-500 max-w-2xl mx-auto">The principles that guide our environmental engineering.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: Leaf, title: "Sustainability", desc: "Eco-friendly disposal and recycling of waste." },
              { icon: ShieldCheck, title: "Compliance", desc: "Adhering to strict environmental regulations for all projects." },
              { icon: TrendingUp, title: "Innovation", desc: "Advanced technology for higher efficiency in energy generation." }
            ].map((item, i) => (
               <div key={i} className="text-center p-8 rounded-2xl hover:bg-gray-50 transition-colors">
                  <div className="inline-block p-4 bg-white rounded-full shadow-md text-eco-600 mb-6">
                    <item.icon size={32} />
                  </div>
                  <h4 className="font-heading text-xl font-bold text-gray-900 mb-3">{item.title}</h4>
                  <p className="text-gray-600">{item.desc}</p>
               </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;