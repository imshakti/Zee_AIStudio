import React from 'react';
import { PROJECTS } from '../constants';
import { MapPin, Zap, ArrowUpRight, ArrowRight } from 'lucide-react';

const Projects: React.FC = () => {
  return (
    <div className="bg-gray-50 min-h-screen">
       <div className="bg-gray-900 pt-32 pb-20 relative overflow-hidden">
        <img 
            src="https://images.unsplash.com/photo-1590486803833-1c5dc8ce3485?q=80&w=2070&auto=format&fit=crop" 
            className="absolute inset-0 w-full h-full object-cover opacity-60"
            alt="Industrial Background"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-gray-900/50 via-gray-900/80 to-gray-900"></div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="font-heading text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-in-up drop-shadow-md">Featured Projects</h1>
          <p className="text-xl text-gray-100 max-w-2xl mx-auto font-light animate-fade-in-up-delay drop-shadow-sm">
            Showcasing our success in Biogas Plants, Waste Management Facilities, and Sewage Treatment Systems.
          </p>
        </div>
      </div>

      <section className="py-20 -mt-10 relative z-20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {PROJECTS.map((project, idx) => (
              <div 
                key={project.id} 
                style={{ animationDelay: `${idx * 150}ms` }}
                className="bg-white rounded-2xl overflow-hidden shadow-xl shadow-gray-200/50 hover:shadow-2xl hover:shadow-eco-900/20 transition-all duration-500 group animate-fade-in-up relative border border-transparent hover:border-eco-100"
              >
                <div className="absolute bottom-0 left-0 w-full h-1.5 bg-gradient-to-r from-eco-500 to-eco-600 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left z-20"></div>
                <div className="relative h-72 overflow-hidden">
                  <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60 group-hover:opacity-80 transition-opacity"></div>
                  
                  <div className="absolute top-4 right-4">
                     <div className="bg-white/20 backdrop-blur-md p-2 rounded-full text-white opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">
                        <ArrowUpRight size={20} />
                     </div>
                  </div>

                  <div className="absolute bottom-6 left-6 text-white">
                    <div className="flex items-center gap-2 text-eco-300 text-sm font-medium mb-2">
                      <MapPin size={16} />
                      <span>{project.location}</span>
                    </div>
                    <div className="inline-flex items-center gap-1.5 bg-white/20 backdrop-blur-md border border-white/10 px-3 py-1 rounded-full text-xs font-semibold">
                       <Zap size={12} className="text-yellow-400" />
                       {project.capacity}
                    </div>
                  </div>
                </div>
                
                <div className="p-8">
                  <h3 className="font-heading text-2xl font-bold text-gray-900 mb-4 group-hover:text-eco-600 transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed mb-6">
                    End-to-end installation and commissioning with advanced technology ensuring maximum efficiency and compliance.
                  </p>
                  <button className="text-sm font-bold uppercase tracking-wider text-gray-900 border-b-2 border-gray-200 group-hover:border-eco-500 transition-colors pb-1">
                    View Details
                  </button>
                </div>
              </div>
            ))}
            
            {/* More Projects CTA */}
            <div className="bg-gray-100 rounded-2xl border-2 border-dashed border-gray-300 flex flex-col items-center justify-center p-8 min-h-[400px] hover:bg-gray-50 transition-colors cursor-pointer group animate-fade-in-up">
                <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mb-6 shadow-sm group-hover:scale-110 transition-transform">
                    <ArrowRight size={24} className="text-gray-400 group-hover:text-eco-600" />
                </div>
                <h3 className="font-heading text-2xl font-bold text-gray-900 mb-2">100+ More Projects</h3>
                <p className="text-gray-500 text-center max-w-xs">Explore our complete portfolio of Biogas, Waste, and Water projects.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Projects;